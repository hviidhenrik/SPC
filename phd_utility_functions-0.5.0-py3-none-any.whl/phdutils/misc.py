"""
Misc utilities, helper functions etc
"""

from typing import List, Union, Optional

import numpy as np
import pandas as pd
import plotly.express as px
from sklearn.cluster import KMeans
from sklearn.decomposition import PCA


def set_seed(seed: int = 1234):
    """
    Helper function to fix the random seed. Does not work with tensorflow.keras methods.
    Use tf.set_seed(1234) for these instead.

    :param seed: the integer seed
    """
    np.random.seed(seed)


def cprint(should_print: Union[bool, int],
           str_to_print: str,
           **kwargs):
    """
    Modified conditional print function that takes a boolean and only prints the provided string if true.

    :param should_print: to print or not
    :param str_to_print: the string to be printed
    """
    if should_print:
        print(str_to_print, **kwargs)


def partition_by_quantiles(df: pd.DataFrame,
                           column_to_partition_by: str,
                           quantiles: Optional[List[float]] = None):
    """
    Function that partitions a dataframe into bins by the quantiles of a specified column.
    A column with partition labels is appended to the dataframe returned by the function.

    :param df: the dataframe to be partitioned into quantile bins
    :param column_to_partition_by: the column to use for deciding the quantile bins
    :param quantiles: a list of quantiles to partition by, defaults to [0, 0.5, 1.]
    :return: the original dataframe with a "partition" column, specifying which partition each row belongs to
    """
    if quantiles is None:
        quantiles = [0, 0.5, 1.]
    bins = pd.qcut(df[column_to_partition_by], quantiles, labels=False)
    df_out = df.copy()
    df_out["partition"] = bins + 1  # add one since the partitions to ARGUE must start in 1
    return df_out


def pca_reduce(df):
    """
    This is a helper function that simply does a PCA and returns the pca object and transformed dataframe.
    To be used before plot_candidate_partitions_by_pca or select_pcs_and_partition_data
    """
    pca = PCA().fit(df)
    x_transformed = pca.transform(df)
    return x_transformed, pca


def plot_candidate_partitions_by_pca(df_transformed, pca):
    """
    This function is a visual aid to guide the number of partitions and which principal components to
    use for clustering. Should be followed by select_pcs_and_partition_data called on the output from this
    using the visual conclusions obtained from this one. Plots adapted from:
    https://plotly.com/python/pca-visualization/

    :param df_transformed: the PCA-transformed dataframe resulting from the sklearn PCA.transform method
    :param pca: the fitted sklearn PCA object resulting
    """

    components = df_transformed
    labels = {str(i): f"PC {i + 1} ({var:.1f}%)" for i, var in enumerate(pca.explained_variance_ratio_ * 100)}
    dimensions = range(np.min([5, df_transformed.shape[1]])) # get available PC's up to a max of 5

    fig = px.scatter_matrix(
        components,
        labels=labels,
        dimensions=dimensions,
    )
    fig.update_traces(diagonal_visible=False)
    fig.show()
    return df_transformed


def select_pcs_and_partition_data(df_transformed,
                                  pcs_to_cluster_on: List[int],
                                  n_clusters: int,
                                  plot_pca_clustering: bool = True):
    """
    This function relies on the visual conclusions from plot_candidate_partitions_by_pca.
    The particular PC's to cluster on can be selected as well as the desired number of clusters/partitions to obtain

    :param df_transformed: the PCA-transformed dataframe resulting from the sklearn PCA.transform method
    :param pcs_to_cluster_on: a list with the indexes of the PC's to use for clustering
    :param n_clusters: the number of clusters desired
    :param plot_pca_clustering: whether to plot the clustering or not
    """

    assert 0 not in pcs_to_cluster_on, "PC's must be given by indices starting from 1"
    pcs_to_cluster_on = [i-1 for i in pcs_to_cluster_on]  # convert to actual array indices
    clusters = KMeans(n_clusters=n_clusters, n_init=50).fit(df_transformed[:, pcs_to_cluster_on])
    partition_labels = clusters.labels_ + 1
    if plot_pca_clustering:
        components = df_transformed
        dimensions = range(np.min([5, df_transformed.shape[1]])) # get available PC's up to a max of 5
        labels = {str(i): f"PC {i+1}" for i in dimensions}

        fig = px.scatter_matrix(
            components,
            labels=labels,
            dimensions=dimensions,
            color=partition_labels
        )
        fig.update_traces(diagonal_visible=False)
        fig.show()
    return partition_labels


def make_time_elapsed_string(elapsed_time, secs_to_min_threshold: int = 180):
    """
    Simple function that converts a number of seconds to a readable string, possibly formatted in minutes.

    :param elapsed_time: number of seconds, float or int
    :param secs_to_min_threshold: the maximum number of seconds before result is converted to minutes
    :return:
    """
    return f"{elapsed_time:.2f} seconds!" if elapsed_time < secs_to_min_threshold else \
        f"{elapsed_time / 60:.2f} minutes!"
